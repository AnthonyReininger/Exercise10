<template>
  <div>
    <h2>Uhh...cool photos</h2>
    <hr>
    <div class="row" style="margin: 0 auto; margin-bottom: 2%;">
      <div class="col-md-2">
      <div class="card">
        <img  class="card-img-top" src="https://dummyimage.com/350x350/c7c7c7/000.png" alt="Card Image cap">
      </div>
    </div>
    </div>
    <div class="row" style="margin: 0 auto; margin-bottom: 2%;">
      <div class="col-md-2">
        <div class="card">
          <img  class="card-img-top" src="https://dummyimage.com/350x350/c7c7c7/000.png" alt="Card Image cap">
        </div>
      </div>
    </div>
    <div class="row" style="margin: 0 auto; margin-bottom: 2%;">
      <div class="col-md-2">
        <div class="card">
          <img  class="card-img-top" src="https://dummyimage.com/350x350/c7c7c7/000.png" alt="Card Image cap">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "uh"
    }
</script>

<style scoped>

</style>
