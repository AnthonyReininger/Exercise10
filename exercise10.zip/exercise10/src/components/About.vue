<template>
    <div>
      <h1>The About Page</h1>
      <hr>
      <h2>Hobbies and interests</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa eos obcaecati possimus quas ullam! Delectus dolor iure iusto maxime molestiae natus nostrum odio optio, perferendis provident suscipit tempore vel voluptatibus?</p>
      <h2></h2>
    </div>
</template>

<script>
    export default {
        name: "about"
    }
</script>

<style scoped>

</style>
