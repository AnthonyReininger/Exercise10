<template>
  <div>
    <h1>The Home Page</h1>
    <hr>
    <h2><i>Hello, select your console of choice..</i></h2>
    <hr>
    <ul class="list-group">
      <router-link
        tag="li"
        :to="{ name: 'console', params: { id: 1 }, query: { locale: 'en', q: 100 } }"
        class="list-group-item"
        style="cursor: pointer">PS4</router-link>
      <router-link
        tag="li"
        :to="{ name: 'console', params: { id: 2 }, query: { locale: 'en', q: 100 } }"
        class="list-group-item"
        style="cursor: pointer">X-Box</router-link>
      <router-link
        tag="li"
        :to="{ name: 'console', params: { id: 3 }, query: { locale: 'en', q: 100 } }"
        class="list-group-item"
        style="cursor: pointer">PC</router-link>
    </ul>
  </div>
</template>

