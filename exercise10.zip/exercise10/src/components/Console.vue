<template>
  <div>
    <h3>Console Specs</h3>
    <p>User loaded has picked: {{ $route.params.id }}</p>
    <p>Locale: {{ $route.query.locale }}</p>
    <p>Analytics: {{ $route.query.q }}</p>
    <hr>
    <button @click="navigateToHome" class="btn btn-primary">Submit</button>
  </div>
</template>

<script>
  export default {
    methods: {
      navigateToHome() {
        this.$router.push({ name: 'home' });
      }
    }
  }
</script>

<style scoped>

</style>
