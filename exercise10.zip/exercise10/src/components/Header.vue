<template>
  <div class="container " style="margin-top: 2%; margin-bottom: 2%;">
    <ul class="nav nav-pills" style="padding-left: 1.5%;">
      <router-link to="/" tag="li" active-class="active" exact><a>Home</a></router-link>
      <router-link to="/about" tag="li" active-class="active"><a>About</a></router-link>
      <router-link to="/contact" tag="li" active-class="active"><a>Contact</a></router-link>
      <router-link to="/uh" tag="li" active-class="active"><a>Uhh..</a></router-link>
    </ul>
  </div>
</template>

