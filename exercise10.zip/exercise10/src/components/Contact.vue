<template>
  <div>
    <h2>Wanna Chat?</h2>
    <hr>
    <form action="">
      <div class="form-group">
        <label for="example-text-input" class="col-2 col-form-label">Name:</label>
        <div class="col-10">
          <input class="form-control" type="text" id="example-text-input">
        </div>
      </div>
      <div class="form-group">
        <label for="example-text-input" class="col-2 col-form-label">Email:</label>
        <div class="col-10">
          <input class="form-control" type="text" id="example-text-input">
        </div>
      </div>
      <div class="form-group">
        <label for="comment">Comment:</label>
        <textarea class="form-control" rows="5" id="comment"></textarea>
      </div>
      <button @click="navigateToHome" class="btn btn-primary">Submit</button>
    </form>
  </div>
</template>

<script>
    export default {
      methods: {
        navigateToHome() {
          this.$router.push({ name: 'home' });
        }
      }
    }
</script>

<style scoped>

</style>
