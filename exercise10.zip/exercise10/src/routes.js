import Home from './components/Home.vue';
import About from './components/About.vue';
import Contact from './components/Contact.vue';
import Uh from './components/Uh.vue';
import Console from './components/Console.vue';

export const routes= [
  {path: '', component: Home},
  {path: '/about', component: About},
  {path: '/contact', component: Contact},
  {path: '/uh', component: Uh},
  {path: '/console/:id', component: Console, name: 'console'},
  {path: '/redirect-me', redirect: {name: 'home'}},
  {path: '*', redirect: '/'}
];
